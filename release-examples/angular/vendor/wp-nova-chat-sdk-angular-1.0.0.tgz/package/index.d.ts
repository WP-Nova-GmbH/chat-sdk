import * as _wp_nova_chat_sdk from '@wp-nova/chat-sdk';
import { SdkConfig, ToolDefinition, ToolHandler } from '@wp-nova/chat-sdk';
export { SdkConfig, ToolDefinition, ToolHandler } from '@wp-nova/chat-sdk';
import * as i0 from '@angular/core';
import { OnInit, OnChanges, OnDestroy, SimpleChanges, InjectionToken, EnvironmentProviders } from '@angular/core';

declare class NovaChatComponent implements OnInit, OnChanges, OnDestroy {
    config?: SdkConfig;
    tools?: readonly ToolDefinition[];
    enabled: boolean;
    private readonly nova;
    /** name -> last applied signature + handler identity, for delta re-registration. */
    private readonly registered;
    /** True between the first `retain()` and its paired `release()`. */
    private retained;
    private firstSync;
    private lastDisabledMessage?;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    private unregisterTools;
    private sync;
    /** Apply only the tool delta: unregister removed, (re)register new/changed. */
    private syncTools;
    static ɵfac: i0.ɵɵFactoryDeclaration<NovaChatComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NovaChatComponent, "wp-nova-chat-mount", never, { "config": { "alias": "config"; "required": false; }; "tools": { "alias": "tools"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; }, {}, never, never, true, never>;
}

declare class NovaChatService {
    private readonly config;
    private sdk?;
    init(config?: _wp_nova_chat_sdk.SdkConfig): void;
    registerTool(tool: ToolDefinition): void;
    unregisterTool(name: string): void;
    /** @deprecated Use registerTool with the full tool definition. */
    registerToolHandler(name: string, handler: ToolHandler): void;
    /** @deprecated Use unregisterTool for SDK-declared tools. */
    unregisterToolHandler(name: string): void;
    /**
     * Register a live mount of the shared chat element. Pairs with `release`; the
     * shared element is torn down only when the last mount releases, so one
     * NovaChatComponent unmounting never destroys another's live chat.
     */
    retain(): void;
    /** Drop a live mount registered with `retain`. */
    release(): void;
    destroy(): void;
    private load;
    static ɵfac: i0.ɵɵFactoryDeclaration<NovaChatService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NovaChatService>;
}

declare const NOVA_CHAT_CONFIG: InjectionToken<SdkConfig>;

declare function provideNovaChat(config: SdkConfig): EnvironmentProviders;

export { NOVA_CHAT_CONFIG, NovaChatComponent, NovaChatService, provideNovaChat };
