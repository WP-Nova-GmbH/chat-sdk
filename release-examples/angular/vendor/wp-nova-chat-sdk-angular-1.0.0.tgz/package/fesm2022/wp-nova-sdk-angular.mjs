import * as i0 from '@angular/core';
import { InjectionToken, inject, Injectable, Input, Component, makeEnvironmentProviders, ENVIRONMENT_INITIALIZER } from '@angular/core';

function reportAngularOperationError(operation, error) {
    const message = formatErrorMessage(error);
    if (message.startsWith("[wp-nova]"))
        return;
    console.error(`[wp-nova/angular] ${operation} failed: ${message}`);
}
function disabledConfigMessage(config) {
    if (!config)
        return null;
    const missing = missingRequiredConfigFields(config);
    if (missing.length === 0)
        return null;
    return ("[wp-nova/angular] NovaChatComponent did not mount the chat launcher because " +
        `enabled=false and required config is missing: ${missing.join(", ")}.`);
}
function formatErrorMessage(error) {
    return error instanceof Error ? error.message : String(error);
}
function missingRequiredConfigFields(config) {
    const missing = [];
    if (!config.publicSurfaceId?.trim())
        missing.push("publicSurfaceId");
    if (!config.tokenEndpoint?.trim())
        missing.push("tokenEndpoint");
    return missing;
}

const NOVA_CHAT_CONFIG = new InjectionToken("NOVA_CHAT_CONFIG");

class NovaChatService {
    config = inject(NOVA_CHAT_CONFIG, { optional: true });
    sdk;
    init(config = this.config) {
        if (!config) {
            const message = "[wp-nova/angular] NovaChatService.init requires an SdkConfig; the chat launcher was not mounted.";
            console.error(message);
            throw new Error(message);
        }
        void this.load()
            .then((sdk) => sdk.init(config))
            .catch((error) => reportAngularOperationError("init", error));
    }
    registerTool(tool) {
        void this.load()
            .then((sdk) => sdk.registerTool(tool))
            .catch((error) => reportAngularOperationError(`registerTool("${tool.name}")`, error));
    }
    unregisterTool(name) {
        void this.load()
            .then((sdk) => sdk.unregisterTool(name))
            .catch((error) => reportAngularOperationError(`unregisterTool("${name}")`, error));
    }
    /** @deprecated Use registerTool with the full tool definition. */
    registerToolHandler(name, handler) {
        void this.load()
            .then((sdk) => sdk.registerToolHandler(name, handler))
            .catch((error) => reportAngularOperationError(`registerToolHandler("${name}")`, error));
    }
    /** @deprecated Use unregisterTool for SDK-declared tools. */
    unregisterToolHandler(name) {
        void this.load()
            .then((sdk) => sdk.unregisterToolHandler(name))
            .catch((error) => reportAngularOperationError(`unregisterToolHandler("${name}")`, error));
    }
    /**
     * Register a live mount of the shared chat element. Pairs with `release`; the
     * shared element is torn down only when the last mount releases, so one
     * NovaChatComponent unmounting never destroys another's live chat.
     */
    retain() {
        void this.load()
            .then((sdk) => sdk.retain())
            .catch((error) => reportAngularOperationError("retain", error));
    }
    /** Drop a live mount registered with `retain`. */
    release() {
        void this.load()
            .then((sdk) => sdk.release())
            .catch((error) => reportAngularOperationError("release", error));
    }
    destroy() {
        void this.load()
            .then((sdk) => sdk.destroy())
            .catch((error) => reportAngularOperationError("destroy", error));
    }
    load() {
        this.sdk ??= import('@wp-nova/chat-sdk');
        return this.sdk;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: NovaChatService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: NovaChatService, providedIn: "root" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: NovaChatService, decorators: [{
            type: Injectable,
            args: [{ providedIn: "root" }]
        }] });

/** The serializable tool fields whose change requires a re-`registerTool`. */
function toolSignature(tool) {
    return JSON.stringify([
        tool.description,
        tool.inputSchema,
        tool.mutating,
        tool.confirmationCopy,
    ]);
}
class NovaChatComponent {
    config;
    tools;
    enabled = true;
    nova = inject(NovaChatService);
    /** name -> last applied signature + handler identity, for delta re-registration. */
    registered = new Map();
    /** True between the first `retain()` and its paired `release()`. */
    retained = false;
    firstSync = true;
    lastDisabledMessage;
    ngOnInit() {
        // With bound inputs Angular fires ngOnChanges before ngOnInit; the
        // firstSync flag makes this call a no-op in that case and the canonical
        // first sync when there are no bound inputs (ngOnChanges never fires).
        this.sync();
    }
    ngOnChanges(changes) {
        this.sync(changes);
    }
    ngOnDestroy() {
        this.unregisterTools();
        if (this.retained) {
            this.retained = false;
            this.nova.release();
        }
    }
    unregisterTools() {
        for (const name of Array.from(this.registered.keys())) {
            this.nova.unregisterTool(name);
        }
        this.registered.clear();
    }
    sync(changes) {
        const isFirst = this.firstSync;
        this.firstSync = false;
        if (!this.enabled) {
            const message = disabledConfigMessage(this.config);
            if (message && this.lastDisabledMessage !== message) {
                this.lastDisabledMessage = message;
                console.error(message);
            }
            this.unregisterTools();
            if (this.retained) {
                this.retained = false;
                this.nova.release();
            }
            return;
        }
        this.lastDisabledMessage = undefined;
        if (!this.retained) {
            this.retained = true;
            this.nova.retain();
        }
        const reinit = isFirst || !!changes?.config || !!changes?.enabled;
        if (reinit && this.config)
            this.nova.init(this.config);
        const reTools = isFirst || !!changes?.tools || !!changes?.enabled;
        if (reTools)
            this.syncTools();
    }
    /** Apply only the tool delta: unregister removed, (re)register new/changed. */
    syncTools() {
        const next = this.tools ?? [];
        const nextNames = new Set();
        for (const tool of next) {
            nextNames.add(tool.name);
            const sig = toolSignature(tool);
            const prev = this.registered.get(tool.name);
            if (!prev || prev.sig !== sig || prev.handler !== tool.handler) {
                this.nova.registerTool(tool);
                this.registered.set(tool.name, { sig, handler: tool.handler });
            }
        }
        for (const name of Array.from(this.registered.keys())) {
            if (!nextNames.has(name)) {
                this.nova.unregisterTool(name);
                this.registered.delete(name);
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: NovaChatComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.25", type: NovaChatComponent, isStandalone: true, selector: "wp-nova-chat-mount", inputs: { config: "config", tools: "tools", enabled: "enabled" }, usesOnChanges: true, ngImport: i0, template: "", isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: NovaChatComponent, decorators: [{
            type: Component,
            args: [{
                    selector: "wp-nova-chat-mount",
                    standalone: true,
                    template: "",
                }]
        }], propDecorators: { config: [{
                type: Input
            }], tools: [{
                type: Input
            }], enabled: [{
                type: Input
            }] } });

function provideNovaChat(config) {
    return makeEnvironmentProviders([
        { provide: NOVA_CHAT_CONFIG, useValue: config },
        {
            provide: ENVIRONMENT_INITIALIZER,
            multi: true,
            useValue: () => {
                inject(NovaChatService).init(config);
            },
        },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { NOVA_CHAT_CONFIG, NovaChatComponent, NovaChatService, provideNovaChat };
//# sourceMappingURL=wp-nova-sdk-angular.mjs.map
